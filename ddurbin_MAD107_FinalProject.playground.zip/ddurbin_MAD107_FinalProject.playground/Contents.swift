//: Playground - noun: a place where people can play

import UIKit

struct Player
{
    // structure to hold the data about the player
    // will contain variables for playerName, playerRace
    // playerGender, and playerCharacterClass
    var Name: String
    var Race: Int  // Three options, 0 human, 1 elf, 2 beastman; may be exapanded later for other races
    var Gender: Bool // 1/true is male, 0/false is female
    var CharClass: Int // 0 is Warrior, 1 is Mage, 2 is Rogue, 3 is Ranger, possible expansion later
    var Advantage: Int // Will be set based on charClass
    var Detrmt: Int // Player special Disadvantage Set by Player
    var Bonus: Int // Bonus player gets, set by Player
//---------------------------------------------------------------------------------------------------------------\\
    let specialAdvantage: [Int] = [ 0, 1, 2, 3]
    // 0 = Armor Bonus for Warriors (+1d4 armor roll)
    // 1 = "Tome of Knoledge" for Mages (Free AOE Sleep Spell Tome (Go the Fuck to Sleep))
    // 2 = Envenomed Blade for Rogues Melee attacks do +1d6 poison damage (enemies immune to poison not affected)
    // 3 = Ensorcelled Arrows for Rangers  Ranged attacks do +1d6 true damage (bypasses armor)
//---------------------------------------------------------------------------------------------------------------\\
    let specialDisadvantage: [Int] = [ 0, 1, 2, 3]
    // 0 is Weak Blood; Bleeding lasts 2x as long and weakness to poison
    // 1 is Febile Mind; Magic attacks against the player do +2d6 damage)
    // 2 is Clumsy; stealth actions twice as hard && greater/guranteed crtical fail chance for somethings
    // 3 is Unlucky; -1d6 to saving throws and non-combat actions, will lose at gambling
//---------------------------------------------------------------------------------------------------------------\\
    let characterBonus: [Int] = [ 0, 1, 2, 3]
    // 0 is Mighty Muscles (Should be said with Austrian accent) +1d6 to melee attacks
    // 1 is Depth of Mind; +2d12 spell casting ability (determined at character creation for mages) +1d6 spell damage
    // 2 is Walk Softly +1d6 to stealth actions and +1d4 to stealth crtical chance and damage
    // 3 is Lucky; +1d6 to saving throws and non-combat actions
//---------------------------------------------------------------------------------------------------------------\\
    var charLevel: Int // holds the characters current level
    var maxHealth: Int // holds the character's maximum health
    var curHealth: Int // holds the current health of the character
    var maxMagic: Int // holds maximum magic points
    var curMagic: Int // holds current magic points
    var maxFatigue: Int // holds current fatigue points
    var curFatigue: Int // current fatigue points
    var charXP: Double // holds current xp between levels
//---------------------------------------------------------------------------------------------------------------\\
    
}

//---------------------------------------------------------------------------------------------------------------\\

// Create new player character from the structure
var Frolo = Player(Name: "Frolo", Race: 0, Gender: true, CharClass: 1, Advantage: 1, Detrmt: 0, Bonus: 1, charLevel: 1, maxHealth: 80, curHealth: 80, maxMagic: (50 + 13), curMagic: 63, maxFatigue: 50, curFatigue: 50, charXP: 0)

// this is going to hold the "input" from the user


// arc4random() -- what is this / how to use it?


print("Dazed and confused, you awaken.  As you work your way back from a deep sleep you realize that you are not where you were when you laid down.")
print("You are able to determine that you are in a small room, it is damp, and smells of mold….and death.")
print("There is a single door of forged iron bands set in hardwood in one wall.")
print()


    let actions = [1, 0, 0]


    print("Do you: ")
    print("1. Examine the room?")
    print("2. Examine the door?")
    print("3. Take a nap.")
    print("4. Sit down and cry about your misfortune like a spoiled baby?")
    
    if(actions[0] == 1)
    {
        print("2")
        print("The door is securely locked, and despite the age of the room and the dampness, the door is much too strong for you to break down.")
        print()
    }
    else
    {
        print("Maybe you should try and get out by the door, this doesn’t look like a great place to stay.")
        print()
    }
    
    if(actions[1] == 0)
    {
        print("You spend a fair amount of time examining the few furnishings in the room and move on to the walls and floors..")
        print("Eventually you notice that a brick opposite the door is loose.")
        print("Should you try and pull the brick from the wall?  1. Yes  2. No")
        if(actions[2] == 0)
        {
            print("1")
            print("You are able, with lots of effort, to pry the brick from the wall.")
            print("Inside the hole is an Emerald Key!")
            print()
        }
        else
        {
            print("2")
            print("Well you haven’t found anything better now have you?")
            print()
        }
    }
    
    print("You move quickly to the door and slip the key into the lock, which turns with a soft *click*.")
    print("You step softly into the hall mentally preparing yourself for the dangers that no doubt await.")
print()

print("You are in a branching hallway some 15 feet wide and 8 feet high. The walls are made of dark stone and water has pooled in corners and along the edges of the hall.")
print("Clearly this is a sewer for water runoff, and other, less wholesome things.")
print("You hear a faint scratching in the distance and you remember that sewers such as this are often the home of rats and other scavengers.")
print()

let choicesOne = [1]
    
print("You have three choices of directions, you could turn right and take a hallway that is mostly dark but with a few patches of light coming from the left hand wall.")
print("You can go straight ahead and make your way along a reasonably well it passage that has some areas where water has spilled across the entire passageway.")
print("Or you can turn left, but the corridor looks odd, as though it were shrouded in mist.")
print()

print("Take the 1. Right  2. Straight  3. Left passage?")
    
    if(choicesOne[0] == 1)
    {
        print("2")
        print("You don’t mind getting your feet a bit wet and move quickly straight ahead.")
        
    }
    else // will have conditionals for both other choices, eventually.
    {
        // currently nothing here
    }


print("You advance slowly, but surely, avoiding the water where possible.")
print()

let firstFight = [1]
    
print("There is a faint scratching and scrabbling in the distance.")
    
print("Two points of light in the distance resolve themeselves into the eyes of a rat.  It watches you, and sniffs the air as you come close.  It appears to be ill and weak.")

print("With a sudden loud SQUEEK the rat jumps at you!")
print()

print("You.....")
print("1. Attack the rat.")
print("2. Dodge the rat.")

    if(firstFight[0] == 1)
    {
        print("2")
        print("You quickly dodge aside from the leaping rat.")
        print("It slams head first into the wall behind you and slumps to the floor, it's skull broken.")
        print()
    }
    else
    {
        // stuff that deals with hiting the rat with a weapon
    }


print("With the rat dealt with, you move on and turn left following the hallway.")
print()
let dealingWithRats = [ 1, 1]

print("Now knowing that the sewer has rats in it you move forward with more caution.")

print("You hear more scratching in the distance and prepare a spell of endless sleep.")

print("You channel your magic through your staff as the rat leaps for your throat!")
print()   
    if(dealingWithRats[0] == 1)
    {
        print("You cast your spell with the incantation GO TO SLEEP!")
        print("The rat falls to the ground in an enchanted sleep, never to rise again.")
        print()
    }
    else
    {
        print("Your spell misses the rat, but a sharp jab with your staff hits it in midair knocking it to the ground.  It scampers off into the darkness.")
        print()
    }

print()
print("More hissing and scraping comes from the darkness ahead of you.")

print("You cast a basic Ball of Light down the hallway.")
print("Dozens of rats look back at you, and with a collective hiss, charge.")

print("With a shout of GO THE FUCK TO SLEEP you cast a mass sleep spell!")

    if(dealingWithRats[1] == 1)
    {
        print("A faint *sigh* escapes the rats as they sag into permenate slumber.")
        print("You tip-toe through the rats toward a door way at the end of the passage that you hope leads to a way out of the sewers.")
    }
    else
    {
        print("Your spell miscasts and you are swiftly devoured by hungry rats.  All that is left of you is gnawed bones and bloody cloth.")
    }

let skeletonFight = [0, 1]

print()
print("You quitely shut the door behind you, but as the latch clicks closed you hear a shuffling step.")
print("A Skeleton Warrior is charging you!")
print()

print("Do you 1. Attack the Skeleton with a Fireball or 2. Try to dodge the swing of its axe?")
if(skeletonFight[0] == 0)
{
    print()
    print("1")
    print("You quickly summon a ball of fire and launch it at the skeleton!")
    print()
    print("The skeleton staggers back, chared but intact.")
    print("It moves to attack you again.")
    print()
    
    print("Do you...")
    print("1. Try to trip it with your staff?")
    print("2. Try to immolate the skeleton with a Cone of Fire?")
    
    if(skeletonFight[1] == 1)
    {
        print()
        print("2")
        print("You gather the last of your magical reserves and cast a systaned Cone of Fire upon the skeleton.")
        print("The air shimmers with haze and the smell of chared bones fills the room.")
        print("With a loud *thud* the skeleton's axe falls to the floor, shortly followed by the rattle of bones as the magic animating the skeleton fades.")
        print()
        print()
        print("You move to a ladder set in the back wall of the chamber, upon climbing it you find a small platform with a second, shorter ladder leading to a drainage grate. Peering through the grate you can see part of a town wall, though you think you may be outside rather than inside the town.")
        print("You lift the grate and exit the sewers quickly. While you are unsure why you were left in the sewers you expect that you will find your answers soon enough and move forward toward the town and the answers you seek.")
        
    }
    else
    {
        print()
        print("1")
        print("In your haste you trip on the hem of your cloak. Before you can rise the skeleton moves in and cuts your head off in a single downward chop.")
    }
    
}
else
{
    print()
    print("2")
    print("As you duck quickly to the side the chop of the skeleton's axe becomes a swing, catching you on the shoulder; you are greviously wounded.")
    print("The skeleton moves in for the kill.")
}










